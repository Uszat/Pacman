#include "pacman.h"

Pacman::Pacman(int initX, int initY,const  char* path, QWidget *parent): Player(initX, initY, path, parent){
    
    speed = 4;
    setup();
    
}
QPoint Pacman::getPosition(){
    return position;
}

 void Pacman::setup(){
    
    for (int i = 0; i< 28; i++) {
        for (int j = 0; j< 31; j++) {
            tiles[j][i].xPos = 16*i + 8;
            tiles[j][i].yPos = 16*j + 8;
            switch(tilesMap[j][i]) {
            case 1:
                tiles[j][i].wall = true;
                break;
            case 2:
                tiles[j][i].wall = true;
                break;
            case 0: 
                tiles[j][i].dot = true;
                break;
            case 3: 
                tiles[j][i].dot = true;
                break;
            case 8: 
                tiles[j][i].bigDot = true;
                break;
            }   
        }
    }	
}



void Pacman::move(){
    turnTo();
    setTurn();
    teleport();
	playerRect.moveTo(position);
}

