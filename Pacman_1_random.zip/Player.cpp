#include "Player.h"

#define PLAYER_LENGTH 16

Player::Player(int initX, int initY, const char *path, QWidget *parent): QWidget(parent){
    
    
    playerRect = QRect(initX, initY, PLAYER_LENGTH, PLAYER_LENGTH);
 	imgPlayer = QImage(path);
	position = QPoint(initX, initY);
    Timer = new QTimer(this);
    connect(Timer, SIGNAL(timeout()), this, SLOT(move()));
    Timer->start(50);
   
    
}

void Player::paint(QPainter * painter){
	
    painter->drawImage(playerRect, imgPlayer);
}

void Player::setPath(const char *path){
    imgPlayer = QImage(path);
}

Direction Player::turnTo(){
	
    int xLeft = (position.x()-1)/PLAYER_LENGTH;
    int yUp = (position.y()-1)/PLAYER_LENGTH;
	int xRight = (position.x()+17)/PLAYER_LENGTH;
    int yDown = (position.y()+17)/PLAYER_LENGTH;
	
    
    int xFloor = position.x()/PLAYER_LENGTH;
    int yFloor = position.y()/PLAYER_LENGTH;
    
    int xPlayer = position.x();
    int yPlayer = position.y();
    
        
    
	switch(newOrient){
		case LEFT:
          
			if (!(tiles[yFloor][xLeft].wall) && xPlayer+8 == tiles[yFloor][xFloor].xPos \
				&& yPlayer+8 == tiles[yFloor][xFloor].yPos){
                currentOrient = newOrient;	
			}
			break;
		case UP:
        
			if (!(tiles[yUp][xFloor].wall) && xPlayer+8 == tiles[yFloor][xFloor].xPos \
				&& yPlayer+8 == tiles[yFloor][xFloor].yPos){
                currentOrient = newOrient;
			}
			break;
		case RIGHT:
            
			if (!(tiles[yFloor][xRight].wall) && xPlayer+8 == tiles[yFloor][xFloor].xPos \
				&& yPlayer+8 == tiles[yFloor][xFloor].yPos){
				currentOrient = newOrient;
			}
			break;
		case DOWN:
          
			if (!(tiles[yDown][xFloor].wall) && xPlayer+8 == tiles[yFloor][xFloor].xPos \
				&& yPlayer+8 == tiles[yFloor][xFloor].yPos){
                currentOrient = newOrient;
			}
			break;
        case STOP:
            currentOrient = STOP;
	}
	
	return currentOrient;
}


void Player::setTurn(){
	
    int xLeft = (position.x()-1)/PLAYER_LENGTH;
    int yUp = (position.y()-1)/PLAYER_LENGTH;
	int xRight = (position.x()+1+PLAYER_LENGTH)/PLAYER_LENGTH;
    int yDown = (position.y()+1+PLAYER_LENGTH)/PLAYER_LENGTH;
	
    int xFloor = position.x()/PLAYER_LENGTH;
    int yFloor = position.y()/PLAYER_LENGTH;

    
	 switch(turnTo()){
		case LEFT:

			if (!(tiles[yFloor][xLeft].wall)){
				position.setX(position.x()-speed);
			
			}break;
		case UP:

            
			if (!(tiles[yUp][xFloor].wall)){
				position.setY(position.y()-speed);
				
				
			}break;
		case RIGHT:

			if (!(tiles[yFloor][xRight].wall)){
				position.setX(position.x()+speed);
				
			}break;
		case DOWN:	

			if (!(tiles[yDown][xFloor].wall)){
				position.setY(position.y()+speed);
				
			}break;
        case STOP:
            position.setX(position.x());
            position.setY(position.y());
	}
}

void Player::teleport(){
    
	if (position.x()+PLAYER_LENGTH <= 0 && turnTo() == LEFT) {
		position.setX(28*PLAYER_LENGTH);
    } 
    if (position.x() >= 27 * PLAYER_LENGTH && turnTo() == RIGHT){
		position.setX(0);
		
    }
}

void Player::move(){
    turnTo();
    setTurn();
	teleport();
	playerRect.moveTo(position);

 
}

void Player::pause(){
    newOrient = STOP;
    
}


