#pragma once
#include "Player.h"

class Pacman: public Player{
    
public:
    Pacman(int initX, int initY,const  char*, QWidget * parent = 0);
    
    void setup();
    QPoint getPosition();
	
public slots:
    void move();
};


