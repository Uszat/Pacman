#pragma once
#include "tiles.h"
#include <QTimer>
#include <QPainter>
#include <QWidget>
enum Direction{
	LEFT, RIGHT, UP, DOWN, STOP
};

class Player:public QWidget, public Tiles{
    Q_OBJECT
public:
    int speed = 4;
    enum Direction newOrient;
    enum Direction currentOrient = LEFT;
    Tiles tiles[31][28]; 
    QTimer * Timer;
    QRect playerRect;
	QImage imgPlayer;
    QPoint  position;
    Player(int, int,const  char*, QWidget * parent = 0);
    int setRotation(int angle);
    Direction turnTo();
    void setTurn();
    void paint(QPainter * painter);
    void teleport();
    void setPath(const char *path);
	void pause();
    
public slots:
    void move();
};

