#pragma once
#include "pacman.h"
#include "ghost.h"
#include <QLCDNumber>
#include <QPaintEvent>
#include <QGridLayout>
#include <QGraphicsScene>

class Game: public QWidget{
    Q_OBJECT
public:
    
    Game(QWidget *parent = 0);
    
    Tiles tiles[31][28];
    
    int counter = 0;
    int score = 0;
    int gamepoint = 0;
    bool gameOver = false;
    const char*  inkyPath;
    const char* pinkyPath;
    const char* blinkyPath;
    const char* clydePath;
    bool frightened = false;
    
    
    QLCDNumber *scoreLcd;
    QPixmap *pixMap;
    QTimer * timer;
    QTimer * ghoster;
	QGridLayout *gridlayout;
	QGridLayout *boardLayout;
	QGraphicsScene * scene;
    QVector<Ghost*> ghosts;
    Pacman * pacman;
    Ghost * inky;
    Ghost * pinky;
    Ghost * blinky;
    Ghost * clyde;

    void setNormalPaths();
    void setScaredPaths();
    void setup();
    void spawnPlayer();
    void setTiles();
    void repeat();
    void drawDots();
    void paintEvent(QPaintEvent *); 
	void keyPressEvent(QKeyEvent *event);
	void drawDot(QPainter *painter);
    void drawScore(QPainter *painter);
    void drawGameOver(QPainter *painter);
    void setAngles(double angle);
    int setAngle(Ghost *ghost);
    Ghost* checkIntersection();
    void gamePause();
    void setSpeed(int spd);
    void newGame();
    void moveGhost();
    void drawWin(QPainter *painter);
    void youWin();
    void setOnPos();
    
public slots:
    void updateData();
    void choosePath();

};
