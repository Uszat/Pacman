#pragma once
#include "Player.h"

class Ghost: public Player {
    Q_OBJECT
public:
    
    Ghost(int initX, int initY,const char *path, QWidget * parent = 0);

	QPoint pacPos;    
    int gAngle;
    int previousTurn;
    static int forceOrient;
    
    void movement();
    void setup();
    void chooseTurn();
};

