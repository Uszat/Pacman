#include "ghost.h"
#include <iostream>

int Ghost::forceOrient = 4;

Ghost::Ghost(int initX, int initY,const char *path, QWidget *parent): Player(initX, initY, path, parent){
  
    setup();
}

void Ghost::setup(){
    
    for (int i = 0; i< 28; i++) {
        for (int j = 0; j< 31; j++) {
            tiles[j][i].xPos = 16*i + 8;
            tiles[j][i].yPos = 16*j + 8;
            switch(tilesMap[j][i]) {
            case 1:
                tiles[j][i].wall = true;
                break;
            case 3:
                tiles[j][i].wall = true;
                break;
            }   
        }
    }	
}

void Ghost::movement(){
    
    int choose = rand()%2;
    
    if (currentOrient == LEFT || currentOrient == RIGHT) { // if left right
        
        if (choose == 0) 
            newOrient = UP;
        else if (choose == 1)
            newOrient = DOWN;
    }
    else if (currentOrient == UP || currentOrient == DOWN){//if up down 
        
        if (choose == 0) 
            newOrient = LEFT;
        else if (choose == 1)
            newOrient = RIGHT;
    } 
}


void Ghost::chooseTurn(){

    
    int xLeft = (position.x()-1)/16;
    int yUp = (position.y()-1)/16;
	int xRight = (position.x()+17)/16;
    int yDown = (position.y()+17)/16;
    
    int xFloor = position.x()/16;
    int yFloor = position.y()/16;
    
    if (forceOrient != 4 ){
//         if (gAngle >= 45 &&  gAngle < 135 ){
        if (forceOrient == 1){
			 if ( !(tiles[yUp][xFloor].wall) ){
				newOrient = UP;
                forceOrient = 4;
             }
//         } else if (gAngle >= 135 &&  gAngle < 225){
        }else if (forceOrient == 0){
             if ( !(tiles[yFloor][xLeft].wall)  ){
                    newOrient = LEFT;
                    forceOrient = 4;
//                     std::cout<<"DUPA"<<std::endl;
             }
// 		} else if (gAngle >= 225 &&  gAngle <= 315 ){
            }else if (forceOrient == 3){
			 if ( !(tiles[yDown][xFloor].wall) ){
                newOrient = DOWN;
                forceOrient = 4;
        } 
// 		 }else if ((gAngle >= 315 &&  gAngle <= 360) || (gAngle >= 0 &&  gAngle < 45) ) {
             }else if (forceOrient == 2){
			 if ( !(tiles[yFloor][xRight].wall) ){
				newOrient = RIGHT;
				forceOrient = 4;
			}
		}    
	}  
	else { //std::cout<<"Wszedl w ELSE"<<std::endl;
		if (gAngle >= 45 &&  gAngle < 135 ){
//             std::cout<<"angle UP"<<std::endl;
			if ( !(tiles[yUp][xFloor].wall) ){
				newOrient = UP;
			}else if (  !(tiles[yFloor][xLeft].wall) ) {
				newOrient = LEFT;
				forceOrient = 0; 
           
			}else if (!(tiles[yFloor][xRight].wall)){
				newOrient = RIGHT;
				forceOrient = 2;
			}
		} else if (gAngle >= 135 &&  gAngle < 225){
// 			std::cout<<"angle LEFT"<<std::endl;
            if ( !(tiles[yFloor][xLeft].wall)  ){
				newOrient = LEFT;
			} else if (  !(tiles[yUp][xFloor].wall) ) {
				newOrient = UP;
				forceOrient = 1; 
			}else if (!(tiles[yDown][xFloor].wall)){
				newOrient = DOWN;
				forceOrient = 3;
			}
		}else if (gAngle >= 225 &&  gAngle <= 315 ){
//             std::cout<<"angle DOWN"<<std::endl;
		   if ( !(tiles[yDown][xFloor].wall) ){
				newOrient = DOWN;
			} else if (  !(tiles[yFloor][xLeft].wall) ) {
				newOrient = LEFT;
				forceOrient = 0; 
			}else if (!(tiles[yFloor][xRight].wall)){
				newOrient = RIGHT;
				forceOrient = 2;
			}
		}else if ((gAngle >= 315 &&  gAngle <= 360) || (gAngle >= 0 &&  gAngle < 45) ) {
//             std::cout<<"angle RIGHT"<<std::endl;
			if ( !(tiles[yFloor][xRight].wall) ){
				newOrient = RIGHT;
			} else if (  !(tiles[yUp][xFloor].wall) ) {
				newOrient = UP;
				forceOrient = 1; 
				
			}else if (!(tiles[yDown][xFloor].wall)){
				newOrient = DOWN;
				forceOrient = 3;
			}
		}       
	}
}



/*

!(tiles[yFloor][xLeft].wall)

!(tiles[yFloor][xRight].wall)

!(tiles[yUp][xFloor].wall) 

!(tiles[yDown][xFloor].wall)


*/

// void Ghost::chooseTurn(){
//     
//     int xLeft = (position.x()-1)/16;
//     int yUp = (position.y()-1)/16;
// 	int xRight = (position.x()+17)/16;
//     int yDown = (position.y()+17)/16;
//     
//     int xFloor = position.x()/16;
//     int yFloor = position.y()/16;
//     
//     if (gAngle >= 45 &&  gAngle < 135 ){
//        if ( !(tiles[yUp][xFloor].wall) ){
//             newOrient = UP;
//         } /*else if (*/
//     }else if (gAngle >= 135 &&  gAngle < 225){
//        if ( !(tiles[yFloor][xLeft].wall)  ){
//             newOrient = LEFT;
//         } 
//     }else if (gAngle >= 225 &&  gAngle <= 315 ){
//        if ( !(tiles[yDown][xFloor].wall) ){
//             newOrient = DOWN;
//         } 
//     }else if ((gAngle >= 315 &&  gAngle <= 360) || (gAngle >= 0 &&  gAngle < 45) ) {
//         if ( !(tiles[yFloor][xRight].wall) ){
//             newOrient = RIGHT;
//         }
//     }       
// }
