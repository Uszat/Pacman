#include "game.h"
#include <cmath>
#include <iostream> 

#define PACMAN_INIT_POS 13*16+8,23*16
//#define PACMAN_INIT_POS 6*16+8,10*16
#define BLINKY_INIT_POS 14*16+8,11*16
#define INKY_INIT_POS 14*16+8,11*16
#define PINKY_INIT_POS 13*16+8,11*16
#define CLYDE_INIT_POS 13*16+8,11*16
#define NUMBER_OF_DIGITS 3


Game::Game(QWidget *parent): QWidget(parent){ 

    setup();
    spawnPlayer();
    setTiles();
    updateData();
    repeat();
    gridlayout = new QGridLayout;
	gridlayout -> addWidget(pacman, 0, 0);
     
}

void Game::drawDot(QPainter *painter){
 
    for (int i = 0; i< 28; i++) {
        for (int j = 0; j< 31; j++) {
            if (tiles[j][i].dot && !(tiles[j][i].eaten)){
              
                int x = tiles[j][i].xPos;
                int y = tiles[j][i].yPos;
                
                QRect rect = QRect(x-2, y-2, 4, 4);
                painter->setPen(Qt::yellow);
                painter->drawRect(rect);
                
            }
            if (tiles[j][i].bigDot && !(tiles[j][i].eaten)){
              
                int x = tiles[j][i].xPos;
                int y = tiles[j][i].yPos;
                
                QRect rect = QRect(x-3, y-3, 6, 6);
                painter->setPen(Qt::yellow);
                painter->fillRect(rect, QBrush(Qt::yellow));
                painter->drawRect(rect);
                
            }
        }
    }
}

void Game::drawScore(QPainter *painter){
    painter->setPen(Qt::black);
    painter->setFont(QFont("times",20, QFont::Bold));
    painter->drawText(100,530, "Score: ");
    
    char text[20];
    sprintf(text, "%d", score);
    const char *cScore = text;
    painter->drawText(185,530, cScore);
    
}

void Game::drawGameOver(QPainter *painter){
     if (gameOver){
        painter->setPen(Qt::red);
        painter->setFont(QFont("times",30, QFont::Bold));
        painter->drawText(125,245, "Game Over");
    }
}


 void Game::paintEvent(QPaintEvent *){
    
    QPainter painter(this);
    
    painter.drawPixmap(0,0,448,496,*pixMap);
    
	pacman->paint(&painter);
    drawDot(&painter);
    drawScore(&painter);
    for(int i = 0; i < ghosts.size(); i++){
        ghosts[i]->paint(&painter);
    }
//     inky->paint(&painter);
    drawGameOver(&painter);
   drawWin(&painter);
}

void Game::drawWin(QPainter *painter){
     if (gamepoint == 246){
        painter->setPen(Qt::green);
        painter->setFont(QFont("times",30, QFont::Bold));
        painter->drawText(125,245, "You Win!!!");
    }
}

void Game::repeat(){
     
    timer  = new QTimer(this);
    //ghoster = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateData()));
    //connect(ghoster, SIGNAL(timeout()), this, SLOT(choosePath()));
    timer->start(50);
    //ghoster->start(50);
    
    
}

void Game::newGame(){
    gameOver = false;
    gamepoint = 0;
   // ghoster->start(50);
    score = 0;
    pacman->newOrient = LEFT;
    setTiles();
         
    for(int i = 0; i < ghosts.size(); i++){
        ghosts[i]->position.setX(14*16);
        ghosts[i]->position.setY(11*16);
        ghosts[i]->newOrient = LEFT;
    }
    pacman->position.setX(13*16);
    pacman->position.setY(23*16);
    
}


void Game::gamePause(){
    
    pacman->pause();
    //ghoster->stop();
     for(int i = 0; i < ghosts.size(); i++){
        ghosts[i]->pause();
    }
}

void Game::youWin(){
    gamePause();

}

void Game::setup(){
    
    setFixedSize(448,550);
    pixMap = new QPixmap("map.jpg");
	
    
}


void Game::setScaredPaths(){
    
    for(int i = 0; i < ghosts.size(); i++){
        ghosts[i]->setPath("scared.png");
    }  
}

void Game::setNormalPaths(){
    inky->setPath("inky.png");
    pinky->setPath("pinky.png");
    blinky->setPath("blinky.png");
    clyde->setPath("clyde.png");
}

void Game::spawnPlayer(){
    
    pacman = new Pacman(PACMAN_INIT_POS, "pacman.png");
    inky = new Ghost(INKY_INIT_POS, "inky.png");
    pinky = new Ghost(PINKY_INIT_POS, "pinky.png");
    blinky = new Ghost(BLINKY_INIT_POS, "blinky.png");
    clyde  = new Ghost(CLYDE_INIT_POS, "clyde.png");
    ghosts.push_back(inky);
    ghosts.push_back(pinky);
    ghosts.push_back(blinky);
    ghosts.push_back(clyde);
    
}

void Game::setTiles(){

    for (int i = 0; i< 28; i++) {
        for (int j = 0; j< 31; j++) {
            tiles[j][i].xPos = 16*i + 8;
            tiles[j][i].yPos = 16*j + 8;
            tiles[j][i].eaten = false;
            switch(tiles[0][0].tilesMap[j][i]) {
            case 1:
                tiles[j][i].wall = true;
                break;
            case 2:
                tiles[j][i].wall = true;
                break;
            case 0: 
                tiles[j][i].dot = true;
                break;
            case 8: 
                tiles[j][i].bigDot = true;
                break;
            }   
        }
    }	
    
}

void Game::setSpeed(int spd){
     for(int i = 0; i < ghosts.size(); i++){
        ghosts[i]->speed = spd;
    }
}

void Game::moveGhost(){
	 for(int i = 0; i < ghosts.size(); i++){
        ghosts[i]->movement();
    }}

void Game::keyPressEvent(QKeyEvent *event){
   
    if (event->key() == Qt::Key_Left){
        pacman->newOrient = LEFT;
    }
    else if (event->key() == Qt::Key_Up){
        pacman->newOrient = UP;  
    }
    else if (event->key() == Qt::Key_Right){
        pacman->newOrient = RIGHT;
    }
    else if (event->key() == Qt::Key_Down){
        pacman->newOrient = DOWN;
    } else if (event->key() == Qt::Key_N){
        newGame();
    }
    
}

void Game::updateData(){
    
    int xPac = pacman->position.x();
    int xPacFloor = pacman->position.x()/16;
    int yPacFloor = pacman->position.y()/16;
    
    pacman->setFocus();
    //moveGhost();
    choosePath();
    
    if (!(tiles[yPacFloor][xPacFloor].eaten) && tiles[yPacFloor][xPacFloor].dot && \
        xPac+8 == tiles[yPacFloor][xPacFloor].xPos ){
        tiles[yPacFloor][xPacFloor].eaten = true;
        score++;
        gamepoint++;
    }
    if (!(tiles[yPacFloor][xPacFloor].eaten) && tiles[yPacFloor][xPacFloor].bigDot && \
        xPac+8 == tiles[yPacFloor][xPacFloor].xPos ){
        tiles[yPacFloor][xPacFloor].eaten = true;
        frightened = true;
        score += 5;
        gamepoint++;
        setScaredPaths();
    }
    update();
    if (frightened) {
        counter++;
        setSpeed(2);
        if (counter == 120){
            frightened = false;
            counter = 0;
            setSpeed(4);
            setNormalPaths(); 
            //moveGhost();
        }
    }
   
    if(checkIntersection() && !frightened){
        gameOver = true;
        update();
        gamePause();
       
        }
        
    if(checkIntersection() && frightened){
       
       checkIntersection()->position.setX(14*16);
       checkIntersection()->position.setY(11*16);
       
    } 
    if(gamepoint == 246){
        youWin();
    }
}



void Game::choosePath(){
    

    if (frightened){
        inky->gAngle = (setAngle(inky) + 180) % 360;
        pinky->gAngle = (setAngle(pinky) + 200) % 360;
        blinky->gAngle = (setAngle(blinky) + 225) % 360;
        clyde->gAngle = (setAngle(clyde) - 255) % 360; 
    }else {
        
        inky->gAngle = setAngle(inky);
//        std::cout<<setAngle(inky)<<std::endl;
        pinky->gAngle = (setAngle(pinky) + 25) % 360;
        blinky->gAngle = (setAngle(blinky) + 17) % 360;
        clyde->gAngle = (setAngle(clyde) - 19) % 360; 
    }
//     inky->chooseTurn();

    for(int i = 0; i < ghosts.size(); i++){
       ghosts[i]->chooseTurn();
   }
}

int Game::setAngle(Ghost *ghost){
    
    double xGhost = ghost->position.x();
    double yGhost = ghost->position.y();
    double xPacman = pacman->position.x();
    double yPacman = pacman->position.y();
    double angle;
    int ret;
    
    
//      std::cout<<"forceorient: "<<Ghost::forceOrient<<std::endl;
     
//     if (Ghost::forceOrient == 4) {
  
		if (xGhost != xPacman){
			
			double x = (xGhost -  xPacman);
			double y = (yPacman - yGhost);
		
			angle = atan(y/x)*180/M_PI;
			
			if (x<0) {
				angle += 180;   
			}
			int deg = angle;
			deg = (180 + deg)%360;            
			angle = deg;

		} else  {
			if (yGhost > yPacman){
				angle = 90;
			}
			if (yGhost < yPacman) {
				angle = 270;
			}
		}
// 		std::cout<<"ret angle"<<std::endl;
		return ret = angle;
		
		
//     } else {
		//std::cout<<"force orient"<<std::endl;
// 		return Ghost::forceOrient;
// 		} 

}



Ghost* Game::checkIntersection(){
    
    for(int i = 0; i < ghosts.size(); i++){
        if(pacman->playerRect.intersects(ghosts[i]->playerRect)){
            return ghosts[i];
        } 
    }
    return 0; 
}   







